package com.fitrank.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*
import android.content.Context

class MainActivity : Activity() {
    private val bg = Color.rgb(7, 13, 23)
    private val panel = Color.rgb(15, 26, 42)
    private val blue = Color.rgb(0, 145, 255)
    private val white = Color.rgb(239, 246, 255)
    private val muted = Color.rgb(151, 172, 199)
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private val prefs by lazy { getSharedPreferences("fitrank", Context.MODE_PRIVATE) }
    private var xp = 0
    private var sessions = 0
    private var totalSets = 0
    private var totalReps = 0
    private var selectedTab = "Beranda"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        xp = prefs.getInt("xp", 0)
        sessions = prefs.getInt("sessions", 0)
        totalSets = prefs.getInt("sets", 0)
        totalReps = prefs.getInt("reps", 0)
        buildShell()
        showHome()
    }

    private fun buildShell() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(16), dp(16), dp(16), dp(8))
        }
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(4), dp(4), dp(4), dp(14))
        }
        header.addView(label("F  FitRank", 29, white, true))
        header.addView(label("LATIHAN • NAIK RANK • JADI VERSI TERBAIK", 11, muted, true))
        root.addView(header)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        lateinit var nav: LinearLayout
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(8), 0, dp(4))
        }
        listOf("Beranda", "Workout", "Catatan", "Rank", "Profil").forEach { tab ->
            val b = TextView(this).apply {
                text = tab
                textSize = 11f
                gravity = Gravity.CENTER
                setTextColor(if (tab == selectedTab) blue else muted)
                setPadding(dp(5), dp(12), dp(5), dp(12))
                setOnClickListener {
                    selectedTab = tab
                    when (tab) {
                        "Beranda" -> showHome()
                        "Workout" -> showWorkouts()
                        "Catatan" -> showLog()
                        "Rank" -> showRanks()
                        else -> showProfile()
                    }
                    // Update nav tint after changing content.
                    for (i in 0 until nav.childCount) {
                        (nav.getChildAt(i) as TextView).setTextColor(
                            if ((nav.getChildAt(i) as TextView).text == selectedTab) blue else muted
                        )
                    }
                }
            }
            nav.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(nav)
        setContentView(root)
    }

    private fun showHome() {
        content.removeAllViews()
        val rank = rankFor(xp)
        card {
            addView(label("Halo, FitRider 👋", 22, white, true))
            addView(label("Bangun kebiasaan. Kumpulkan XP. Naik rank.", 13, muted))
            val row = LinearLayout(this@MainActivity).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(badge(rank.first, rank.second), LinearLayout.LayoutParams(dp(82), dp(82)))
            val details = LinearLayout(this@MainActivity).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
            details.addView(label(rank.first, 20, white, true))
            details.addView(label("Level ${xp / 100 + 1} • $xp XP", 13, muted))
            details.addView(progressBar((xp % 100), 100))
            details.addView(label("${100 - (xp % 100)} XP menuju level berikutnya", 11, muted))
            row.addView(details, LinearLayout.LayoutParams(0, -2, 1f))
            addView(row)
        }
        sectionTitle("Statistikmu")
        statsRow("Workout", sessions.toString(), "Total set", totalSets.toString(), "Repetisi", totalReps.toString())
        sectionTitle("Mulai latihan")
        workoutCard("Full Body Blast", "45 menit • Menengah", "Latihan seluruh tubuh") { finishWorkout("Full Body Blast") }
        workoutCard("Upper Body Strength", "40 menit • Menengah", "Dada, punggung, bahu, lengan") { finishWorkout("Upper Body Strength") }
        workoutCard("Leg Day Power", "40 menit • Menengah", "Kaki dan core") { finishWorkout("Leg Day Power") }
        sectionTitle("Akses cepat")
        actionButton("Lihat semua rank") { showRanks() }
        actionButton("Catat latihan") { showLog() }
    }

    private fun showWorkouts() {
        content.removeAllViews()
        sectionTitle("Program Workout")
        addText("Pilih program, lalu tandai selesai untuk mendapat XP. Sesuaikan beban dengan kemampuanmu dan utamakan teknik yang aman.")
        workoutCard("Full Body Blast", "45 menit • Pemula–menengah", "Squat, push-up, row, plank") { finishWorkout("Full Body Blast") }
        workoutCard("Upper Body Strength", "40 menit • Pemula–menengah", "Push, pull, bahu, lengan") { finishWorkout("Upper Body Strength") }
        workoutCard("Leg Day Power", "40 menit • Pemula–menengah", "Squat, lunge, glute bridge") { finishWorkout("Leg Day Power") }
        workoutCard("Recovery & Mobility", "15 menit • Ringan", "Mobilitas dan peregangan nyaman") { finishWorkout("Recovery & Mobility") }
        addText("Program ini adalah contoh umum. Hentikan gerakan jika terasa sakit dan minta bantuan pelatih bila perlu.")
    }

    private fun showLog() {
        content.removeAllViews()
        sectionTitle("Catatan Latihan")
        addText("Simpan sesi latihan di perangkat. Data ini tersedia offline.")
        val exercise = EditText(this).apply {
            hint = "Nama latihan (contoh: Squat)"
            setHintTextColor(muted); setTextColor(white); textSize = 15f
            background = rounded(panel, 12); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        val sets = numberInput("Jumlah set", "3")
        val reps = numberInput("Repetisi per set", "10")
        val weight = EditText(this).apply {
            hint = "Beban (kg), opsional"; setHintTextColor(muted); setTextColor(white); textSize = 15f
            inputType = 8194
            background = rounded(panel, 12); setPadding(dp(12), dp(12), dp(12), dp(12))
        }
        content.addView(exercise, marginParams())
        content.addView(sets, marginParams())
        content.addView(reps, marginParams())
        content.addView(weight, marginParams())
        actionButton("Simpan catatan (+10 XP)") {
            val n = exercise.text.toString().trim()
            val s = sets.text.toString().toIntOrNull()
            val r = reps.text.toString().toIntOrNull()
            if (n.isBlank() || s == null || r == null || s !in 1..30 || r !in 1..100) {
                toast("Isi nama latihan, set 1–30, dan repetisi 1–100.")
            } else {
                xp += 10; totalSets += s; totalReps += s * r
                prefs.edit().putInt("xp", xp).putInt("sets", totalSets).putInt("reps", totalReps)
                    .putString("lastExercise", n).putString("lastWeight", weight.text.toString()).apply()
                toast("Catatan tersimpan! +10 XP")
                showLog()
            }
        }
        sectionTitle("Ringkasan")
        addText("Total set tersimpan: $totalSets")
        addText("Total repetisi tersimpan: $totalReps")
        addText("Latihan terakhir: ${prefs.getString("lastExercise", "Belum ada")}")
    }

    private fun showRanks() {
        content.removeAllViews()
        sectionTitle("Rank & XP")
        addText("Kumpulkan XP dari sesi workout dan catatan latihan untuk menaikkan level.")
        val ranks = listOf(
            Triple("Bronze", "Lv 1–10", 0),
            Triple("Silver", "Lv 11–20", 1000),
            Triple("Gold", "Lv 21–30", 2000),
            Triple("Platinum", "Lv 31–40", 3000),
            Triple("Diamond", "Lv 41–50", 4000),
            Triple("Legend", "Lv 51+", 5000)
        )
        ranks.forEachIndexed { index, item ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                background = rounded(panel, 16); setPadding(dp(12), dp(10), dp(12), dp(10))
            }
            row.addView(badge(item.first, index), LinearLayout.LayoutParams(dp(70), dp(70)))
            val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12),0,0,0) }
            col.addView(label(item.first, 17, white, true))
            col.addView(label(item.second, 12, muted))
            col.addView(label(if (xp >= item.third) "Terbuka" else "Butuh ${item.third - xp} XP lagi", 12, if (xp >= item.third) blue else muted))
            row.addView(col, LinearLayout.LayoutParams(0, -2, 1f))
            content.addView(row, marginParams())
        }
        sectionTitle("Leaderboard (demo lokal)")
        addText("Papan ini berisi contoh pemain dan bukan leaderboard online global. Sinkronisasi antarpengguna memerlukan backend.")
        val leaderboard = listOf("1. FitRider — $xp XP", "2. BlueFalcon — 860 XP", "3. NovaLift — 620 XP", "4. IronPulse — 440 XP")
        leaderboard.forEach { addText(it) }
    }

    private fun showProfile() {
        content.removeAllViews()
        sectionTitle("Profil FitRider")
        card {
            addView(label("🏋  FitRider", 22, white, true))
            addView(label("Level ${xp / 100 + 1} • ${rankFor(xp).first}", 15, blue, true))
            addView(label("$xp XP total", 13, muted))
        }
        sectionTitle("Progres")
        addText("Workout selesai: $sessions")
        addText("Total set: $totalSets")
        addText("Total repetisi: $totalReps")
        addView(progressBar(xp % 100, 100), marginParams())
        addText("${xp % 100}/100 XP menuju level berikutnya")
        actionButton("Reset progres di perangkat") {
            android.app.AlertDialog.Builder(this)
                .setTitle("Reset progres?")
                .setMessage("Semua XP dan statistik lokal akan dihapus.")
                .setNegativeButton("Batal", null)
                .setPositiveButton("Reset") { _, _ ->
                    xp = 0; sessions = 0; totalSets = 0; totalReps = 0
                    prefs.edit().clear().apply()
                    showProfile()
                }.show()
        }
        addText("FitRank menyimpan progres di perangkat ini. Fitur akun dan leaderboard global belum tersambung ke server.")
    }

    private fun finishWorkout(name: String) {
        sessions += 1
        xp += 50
        prefs.edit().putInt("xp", xp).putInt("sessions", sessions).putString("lastWorkout", name).apply()
        toast("$name selesai! +50 XP")
        selectedTab = "Beranda"
        showHome()
    }

    private fun rankFor(points: Int): Pair<String, Int> = when {
        points >= 5000 -> "Legend" to 5
        points >= 4000 -> "Diamond" to 4
        points >= 3000 -> "Platinum" to 3
        points >= 2000 -> "Gold" to 2
        points >= 1000 -> "Silver" to 1
        else -> "Bronze" to 0
    }

    private fun badge(name: String, tier: Int): TextView {
        val colors = listOf(0xFFB8734B.toInt(), 0xFFC5D1DF.toInt(), 0xFFFFC53D.toInt(),
            0xFFB783FF.toInt(), 0xFFFF4B5C.toInt(), 0xFF57C7FF.toInt())
        return TextView(this).apply {
            text = when (tier) { 0 -> "✦"; 1 -> "✧"; 2 -> "★"; 3 -> "✦"; 4 -> "✪"; else -> "♛" }
            textSize = 34f; gravity = Gravity.CENTER; setTextColor(colors[tier.coerceIn(0, 5)])
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.rgb(20, 31, 48))
                setStroke(dp(2), colors[tier.coerceIn(0, 5)])
            }
            contentDescription = "$name rank badge"
        }
    }

    private fun workoutCard(title: String, subtitle: String, description: String, click: () -> Unit) {
        card {
            addView(label(title, 17, white, true))
            addView(label(subtitle, 12, blue, true))
            addView(label(description, 13, muted))
            val b = button("Mulai / Selesaikan")
            b.setOnClickListener { click() }
            addView(b)
        }
    }

    private fun statsRow(a: String, av: String, b: String, bv: String, c: String, cv: String) {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf(a to av, b to bv, c to cv).forEach { pair ->
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL; background = rounded(panel, 12)
                setPadding(dp(9), dp(12), dp(9), dp(12)); gravity = Gravity.CENTER
            }
            box.addView(label(pair.second, 20, white, true))
            box.addView(label(pair.first, 11, muted))
            val lp = LinearLayout.LayoutParams(0, -2, 1f); lp.setMargins(dp(3), 0, dp(3), 0)
            row.addView(box, lp)
        }
        content.addView(row, marginParams())
    }

    private fun card(block: LinearLayout.() -> Unit) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; background = rounded(panel, 18)
            setPadding(dp(15), dp(15), dp(15), dp(15))
        }
        box.block()
        content.addView(box, marginParams())
    }

    private fun sectionTitle(s: String) {
        content.addView(label(s, 20, white, true), marginParams(top = 16, bottom = 8))
    }
    private fun addText(s: String) { content.addView(label(s, 13, muted), marginParams(bottom = 8)) }
    private fun label(s: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            text = s; textSize = size.toFloat(); setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setPadding(0, dp(3), 0, dp(3))
        }
    private fun button(s: String) = Button(this).apply {
        text = s; textSize = 13f; setTextColor(Color.WHITE)
        background = rounded(blue, 24)
        isAllCaps = false
    }
    private fun actionButton(s: String, click: () -> Unit) {
        val b = button(s); b.setOnClickListener { click() }; content.addView(b, marginParams())
    }
    private fun progressBar(progress: Int, max: Int): ProgressBar =
        ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            this.max = max; this.progress = progress
            progressTintList = android.content.res.ColorStateList.valueOf(blue)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Color.rgb(38, 53, 72))
        }
    private fun numberInput(h: String, value: String) = EditText(this).apply {
        hint = h; setHintTextColor(muted); setTextColor(white); setText(value)
        inputType = 2; textSize = 15f; background = rounded(panel, 12)
        setPadding(dp(12), dp(12), dp(12), dp(12))
    }
    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
        if (color == panel) setStroke(dp(1), Color.rgb(37, 57, 80))
    }
    private fun marginParams(top: Int = 0, bottom: Int = 10) =
        LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(top), 0, dp(bottom)) }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
