# FitRank — proyek sumber Android

FitRank adalah prototipe aplikasi fitness Android berbahasa Indonesia dengan tema gelap dan aksen biru. Proyek ini menggunakan Kotlin dan Android SDK tanpa pustaka UI eksternal.

## Fitur yang sudah ada di kode
- Beranda dengan level, XP, dan progres.
- Program workout contoh (Full Body, Upper Body, Leg Day, Recovery).
- Menandai sesi selesai untuk memperoleh XP.
- Catatan latihan dengan nama gerakan, set, repetisi, dan beban opsional.
- Statistik latihan lokal dan penyimpanan melalui SharedPreferences.
- Rank badge original berbasis bentuk/ikon vektor teks: Bronze, Silver, Gold, Platinum, Diamond, Legend.
- Leaderboard contoh lokal (bukan leaderboard online).
- Tombol reset progres.
- Fitur utama dapat berjalan offline.

## Batasan yang perlu diketahui
Ini adalah starter project/prototipe, bukan klon resmi Liftoff. Gambar badge saat ini dibuat langsung oleh kode UI menggunakan simbol dan warna; belum berupa ilustrasi PNG terpisah. Leaderboard masih berisi data contoh lokal. Mode online dan sinkronisasi multi-pengguna memerlukan backend (misalnya Firebase) dan belum diaktifkan. Tidak ada file APK yang disertakan karena APK harus dikompilasi dengan Android SDK/Gradle.

## Build APK
1. Instal Android Studio dari https://developer.android.com/studio.
2. Ekstrak ZIP ini.
3. Di Android Studio pilih **Open**, lalu pilih folder `FitRank`.
4. Pastikan Android SDK Platform 35 dan JDK 17 tersedia; tunggu Gradle Sync selesai.
5. Jalankan di emulator/perangkat, atau pilih **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. APK debug biasanya dibuat di `app/build/outputs/apk/debug/app-debug.apk`.

Alternatif terminal dari folder proyek:
- Windows: `gradlew.bat assembleDebug`
- macOS/Linux: `./gradlew assembleDebug`

Project ini tidak menyertakan Gradle Wrapper JAR atau skrip wrapper; bila wrapper belum ada di mesin, buka melalui Android Studio dan biarkan IDE menyiapkan/menggunakan Gradle, atau buat wrapper dengan instalasi Gradle lokal.

Dokumentasi build resmi: https://developer.android.com/build/building-cmdline


## Build APK otomatis di GitHub (tanpa Android Studio)
File workflow `.github/workflows/android.yml` sudah disertakan.
1. Buat repository baru bernama `FitRank` di GitHub.
2. Upload semua ISI folder proyek ini (jangan upload ZIP sebagai satu file saja), termasuk folder `.github/workflows`.
3. Buka tab **Actions** pada repository. Jika diminta, aktifkan Actions.
4. Pilih workflow **Build FitRank APK**, lalu tekan **Run workflow**. Push ke branch `main` juga akan menjalankan build otomatis.
5. Tunggu job selesai dengan tanda hijau. Buka run tersebut, cari bagian **Artifacts**, lalu unduh `FitRank-debug-APK`.
6. Ekstrak ZIP artifact yang diunduh; di dalamnya ada `app-debug.apk`. Di Android, buka file tersebut untuk memasang, dan izinkan pemasangan dari sumber ini jika diminta.

Catatan: workflow membangun APK debug untuk pengujian. Untuk distribusi publik, buat APK release dan tandatangani dengan keystore yang disimpan secara aman di GitHub Secrets; jangan unggah keystore atau kata sandi ke repositori.
